# Airdrop-CheckMate
Onchain Airdrop Checkmate is a premier, high-fidelity analytics dashboard engineered exclusively for the Base ecosystem.  The platform performs deep-layer synchronization of historical interactions to identify eligibility for: • Token &amp; NFT Airdrops • Meme Coin Distributions • Creator Coin Rewards • Base Builder Grants
